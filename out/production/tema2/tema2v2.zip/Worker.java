import java.io.File;

public class Worker {
    File assignatedFile;
    int indexStart;
    int indexStop;



}
