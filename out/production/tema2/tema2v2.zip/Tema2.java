import com.sun.source.tree.Tree;

import java.io.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;


public class Tema2 {
    static ArrayList<Double> fibonacci = new ArrayList();


    public static void main(String[] args) throws IOException {
        if (args.length < 3) {
            return;
        }

        fibonacci.add(0.0);
        fibonacci.add(1.0);
        for (int i = 2; i < 20; i++) {
            fibonacci.add(fibonacci.get(i - 1) + fibonacci.get(i - 2));
        }

      //  System.out.println("----------------------------------------start tema2-------------------");

        int maximumLengthOfAllWords;

        int numberOfWorkers = Integer.parseInt(args[0]);
        String inFileName = args[1];
        String outFileName = args[2];

        User user = new User(numberOfWorkers, inFileName, outFileName);
        user.coordinator.coordinate();
        // user.coordinator.printResult();

  //      System.out.println("-------------(Map)---------------------");
//        for (int i = 0; i < user.coordinator.mapTasks.size(); i++) {
//            doMap(user.coordinator, i);
//        }

        doMapParallel(user.coordinator, numberOfWorkers);


//        for (int i = 0; i < user.coordinator.mapTasks.size(); i++) {
//            System.out.print(user.coordinator.mapTasks.get(i).mapTaskResult.file + " ");
//            System.out.print(user.coordinator.mapTasks.get(i).mapTaskResult.maxWord + " ");
//            System.out.println(user.coordinator.mapTasks.get(i).mapTaskResult.hashMap);
//        }

     //   System.out.println("------------------(Reduce)--------------------");

//        for (int i = 0; i < user.coordinator.numberOfFiles; i++) {
//            doReduce(user.coordinator.mapTasks, user.coordinator.files, i);
//        }
        doReduceParallel(user.coordinator.mapTasks, user.coordinator.files,user.coordinator.finalResults, numberOfWorkers);
//
        FileWriter fileWriter = new FileWriter(outFileName);
        PrintWriter printWriter = new PrintWriter(fileWriter);

        for(FinalResult f : user.coordinator.finalResults) {
            printWriter.println(f.fileName + "," + String.format("%.02f", f.rang) + "," + f.maxLen + "," + f.maxLenFreq);
        }

        printWriter.close();

    }


    public static void doMap(Coordinator coordinator,int indexTask) throws IOException {
        MapTask currentMapTask = coordinator.mapTasks.get(indexTask);

        InputStream inputFile = new FileInputStream(currentMapTask.file);
        inputFile.skip(currentMapTask.indexStart);

        String currentWord = "";
        String maximumWord = "";

        HashMap<Integer, Integer> taskHashMap = new HashMap<>();

        boolean endOfWord = false;
        char c = 0;
        for (int i = currentMapTask.indexStart; i < currentMapTask.indexStop - 1; i++) {
            c = (char)inputFile.read();
            if (isSeparator(c)) {
                endOfWord = true;

                if (currentWord.length() != 0) {
                    if (taskHashMap.get(currentWord.length()) == null) {
                        taskHashMap.put(currentWord.length(), 1);
                    } else {
                        taskHashMap.put(currentWord.length(), taskHashMap.get(currentWord.length()) + 1);
                    }
                }

                if (currentWord.length() > maximumWord.length()) {
                    maximumWord = currentWord;
                }

                currentWord = "";

            } else {
                endOfWord = false;
            }

            if (!endOfWord) {
                currentWord += c;
            }

            if (endOfWord) {

            }
        }

        if (currentWord.length() != 0) {
            if (taskHashMap.get(currentWord.length()) == null) {
                taskHashMap.put(currentWord.length(), 1);
            } else {
                taskHashMap.put(currentWord.length(), taskHashMap.get(currentWord.length()) + 1);
            }
        }

        if (currentWord.length() > maximumWord.length()) {
            maximumWord = currentWord;
        }

        currentMapTask.mapTaskResult.maxWord = maximumWord;
        currentMapTask.mapTaskResult.hashMap = taskHashMap;

    }

    static void doMapParallel(Coordinator coordinator, int nrOfWorkers) {

        AtomicInteger inQueue = new AtomicInteger(0);
        ExecutorService tpe = Executors.newFixedThreadPool(nrOfWorkers);

        inQueue.incrementAndGet();
        tpe.submit(new MyRunnableMap(coordinator, tpe, inQueue, 0));

        try {
            tpe.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public static void doReduce(ArrayList<MapTask> mapTasks, ArrayList<File> files, int j) {
        // combine
        CombinedTask combinedTask = new CombinedTask((files.get(j)));
        for (int i = 0; i < mapTasks.size(); i++) {
            if (files.get(j).equals(mapTasks.get(i).file)) {
                combinedTask.hashMaps.add(mapTasks.get(i).mapTaskResult.hashMap);
                combinedTask.maximumWords.add(mapTasks.get(i).mapTaskResult.maxWord);
            }
        }

        // process
        Double rang = 0.0;
        Double nrCuvTotal = 0.0;
        int crtFreq = 0;
        int crtMaxLen = -1;
        for (int i = 0; i < combinedTask.hashMaps.size(); i++) {
            for (Map.Entry<Integer, Integer> set :
                    combinedTask.hashMaps.get(i).entrySet()) {
                // Printing all elements of a Map
                rang += fibonacci.get(set.getKey() + 1) * Double.valueOf(set.getValue());
                nrCuvTotal += Double.valueOf(set.getValue());

                if (crtMaxLen == -1) {
                    crtMaxLen = set.getKey();
                    crtFreq += set.getValue();
                } else {
                    if (crtMaxLen == set.getKey()) {
                        crtFreq += set.getValue();
                    } else {
                        if (crtMaxLen < set.getKey()) {
                            crtMaxLen = set.getKey();
                            crtFreq = set.getValue();
                        }
                    }
                }


            }
        }

        rang  /= nrCuvTotal;

        System.out.print(files.get(j).getName() + ".txt, ");
        System.out.print(String.format("%.2f", rang) + ", ");
        System.out.println(crtMaxLen + ", " + crtFreq);
    }

    static void doReduceParallel(ArrayList<MapTask> mapTasks, ArrayList<File> files,Set<FinalResult> finalResults, int nrOfWorkers) {

        AtomicInteger inQueue = new AtomicInteger(0);
        ExecutorService tpe = Executors.newFixedThreadPool(nrOfWorkers);

        inQueue.incrementAndGet();
        tpe.submit(new MyRunnableReduce(mapTasks, files, fibonacci,  finalResults, tpe, inQueue, 0));

        try {
            tpe.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    static boolean isSeparator(char c) {
        String separators = ";:/?~\\.,><`[]{}()!@#$%^&-_+'=*\"| \t\r\n";
        for (int i = 0; i < separators.length(); i++) {
            if (separators.charAt(i) == c) {
                return true;
            }
        }

        return false;

    }
}
