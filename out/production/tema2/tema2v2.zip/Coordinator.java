import java.io.*;
import java.util.*;

public class Coordinator {
    int fragmentSize;
    int numberOfFiles;
    ArrayList<File> files;
    ArrayList<MapTask> mapTasks;
    ArrayList<Worker> workers;
    Set<FinalResult> finalResults;

    public Coordinator(String fileName) throws FileNotFoundException {
        File file = new File((fileName));
        Scanner scanner = new Scanner(file);
        this.files = new ArrayList<>();
        this.fragmentSize = Integer.parseInt(scanner.nextLine());
        this.numberOfFiles = Integer.parseInt(scanner.nextLine());
        this.finalResults = new TreeSet<>(new Comparator<FinalResult>() {
            @Override
            public int compare(FinalResult o1, FinalResult o2) {
                return ((FinalResult) o2).rang.compareTo(((FinalResult) o1).rang);
            }
        });

        int i = 0;
        while (i < numberOfFiles) {
            String line = scanner.nextLine();
            this.files.add(new File((line)));
            i++;
        }

        this.workers = new ArrayList<>();
        this.mapTasks = new ArrayList<>();

    }

    public void coordinate() throws IOException {
        for (File file : files) {
            int i = 0;
            while(i < file.length()) {
                MapTask newMapTask;
                if (i + fragmentSize < file.length()) {
                    newMapTask = new MapTask(file, i, i + fragmentSize, new MapTaskResult(file));
                } else {
                    newMapTask = new MapTask(file, i, (int) file.length(), new MapTaskResult(file));
                }

                mapTasks.add(newMapTask);

                i += fragmentSize;
            }
        }

        for (MapTask t : mapTasks) {
            if (t.indexStart != 0) {
                InputStream inputFile = new FileInputStream(t.file);
                inputFile.skip(t.indexStart - 1);

                if (!isSeparator((char)inputFile.read())) {
                    int c = 0;
                    while (!isSeparator((char)c) && c != -1) {
                        c = inputFile.read();
                        t.indexStart++;
                    }
                }
            }

            if (t.indexStop != t.file.length() - 1) {
                InputStream inputFile = new FileInputStream(t.file);
                inputFile.skip(t.indexStop - 2);
                char a = (char)inputFile.read();
                if (!isSeparator((char)inputFile.read())) {
                    int c = 0;
                    while(!isSeparator((char)c) && c != -1) {
                        c = inputFile.read();
                        t.indexStop++;
                    }
                }
            }
        }
    }
    public void printResult() throws IOException {
        for(MapTask t : mapTasks) {
            System.out.println("task:" + t.indexStart);
            InputStream inputFile = new FileInputStream(t.file);
            inputFile.skip(t.indexStart);
            byte[] b = inputFile.readNBytes(t.indexStop - t.indexStart);
            System.out.print("\"");
            for (int i = 0; i < b.length; i++) {
                System.out.print((char)b[i]);
            }
            System.out.print("\"");
            System.out.println();
            System.out.println("endoftask" + t.indexStop);
          //  System.out.println((inputFile.readAllBytes()).toString());
        }
    }

    boolean isSeparator(char c) {
        String separators = ";:/?~\\.,><`[]{}()!@#$%^&-_+'=*\"| \t\r\n";
        for (int i = 0; i < separators.length(); i++) {
            if (separators.charAt(i) == c) {
                return true;
            }
        }

        return false;

    }
}
