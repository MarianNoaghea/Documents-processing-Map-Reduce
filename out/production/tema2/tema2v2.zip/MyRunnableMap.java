import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;


import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

class MyRunnableMap implements Runnable {
    Coordinator coordinator;
    private final ExecutorService tpe;
    private final AtomicInteger inQueue;
    int step;

    public MyRunnableMap(Coordinator coordinator, ExecutorService tpe, AtomicInteger inQueue, int step) {
        this.coordinator = coordinator;
        this.tpe = tpe;
        this.inQueue = inQueue;
        this.step = step;

    }

    @Override
    public void run() {
        if (step < coordinator.mapTasks.size()) {

            MapTask currentMapTask = coordinator.mapTasks.get(step);

            InputStream inputFile = null;
            try {
                inputFile = new FileInputStream(currentMapTask.file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                inputFile.skip(currentMapTask.indexStart);
            } catch (IOException e) {
                e.printStackTrace();
            }

            String currentWord = "";
            String maximumWord = "";

            HashMap<Integer, Integer> taskHashMap = new HashMap<>();

            boolean endOfWord = false;
            char c = 0;
            for (int i = currentMapTask.indexStart; i < currentMapTask.indexStop - 1; i++) {
                try {
                    c = (char) inputFile.read();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (Tema2.isSeparator(c)) {
                    endOfWord = true;

                    if (currentWord.length() != 0) {
                        if (taskHashMap.get(currentWord.length()) == null) {
                            taskHashMap.put(currentWord.length(), 1);
                        } else {
                            taskHashMap.put(currentWord.length(), taskHashMap.get(currentWord.length()) + 1);
                        }
                    }

                    if (currentWord.length() > maximumWord.length()) {
                        maximumWord = currentWord;
                    }

                    currentWord = "";

                } else {
                    endOfWord = false;
                }

                if (!endOfWord) {
                    currentWord += c;
                }

                if (endOfWord) {

                }
            }

            if (currentWord.length() != 0) {
                if (taskHashMap.get(currentWord.length()) == null) {
                    taskHashMap.put(currentWord.length(), 1);
                } else {
                    taskHashMap.put(currentWord.length(), taskHashMap.get(currentWord.length()) + 1);
                }
            }

            if (currentWord.length() > maximumWord.length()) {
                maximumWord = currentWord;
            }

            currentMapTask.mapTaskResult.maxWord = maximumWord;
            currentMapTask.mapTaskResult.hashMap = taskHashMap;

            inQueue.incrementAndGet();

            tpe.submit(new MyRunnableMap(coordinator, tpe, inQueue, step + 1));
        }

        int left = inQueue.decrementAndGet();
        if (left == 0) {
            tpe.shutdown();
        }
    }
//        if (partialPath.get(partialPath.size() - 1) == destination) {
//            System.out.println(partialPath);
//        } else {
//
//            int lastNodeInPath = partialPath.get(partialPath.size() - 1);
//            for (int[] ints : graph) {
//                if (ints[0] == lastNodeInPath) {
//                    if (partialPath.contains(ints[1]))
//                        continue;
//                    ArrayList<Integer> newPartialPath = new ArrayList<>(partialPath);
//                    newPartialPath.add(ints[1]);
//                    System.out.println(inQueue.incrementAndGet());
//                    tpe.submit(new MyRunnable(newPartialPath, tpe, inQueue, destination, graph));
//                }
//            }
//        }
//
//        int left = inQueue.decrementAndGet();
//        System.out.println(left);
//        if (left == 0) {
//            // System.out.println(partialPath);
//            tpe.shutdown();
//        }
}

