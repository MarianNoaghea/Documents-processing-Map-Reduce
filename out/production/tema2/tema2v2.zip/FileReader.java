import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class FileReader {
    String fileName;
    File file;

    FileReader(String fileName) {
        this.fileName = fileName;
        this.file = new File((fileName));
    }

    public void readFileByteByByte() throws IOException {
        try (FileInputStream fileInputStream = new FileInputStream(file)) {
            int singleCharInt;
            char singleChar;

            while((singleCharInt = fileInputStream.read()) != -1) {
                singleChar = (char) singleCharInt;
                System.out.print(singleChar);
            }
            System.out.println();
        }
    }

    public void readFileLineByLine() throws IOException {
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            System.out.println(line);
        }
    }

    public ArrayList<String> getFilesNames() throws IOException {
        Scanner scanner = new Scanner(file);
        ArrayList<String> documents = new ArrayList<>();
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            documents.add(line);
        }

        return documents;
    }
}
