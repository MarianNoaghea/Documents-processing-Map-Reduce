import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class ReduceTask {
    File file;
    ArrayList<HashMap<Integer, Integer>> hashMaps;
    ArrayList<String> maximumWords;
}
